# ============================================
# CONTEXT OVERFLOW PREVENTION HOOKS
# Add to PowerShell profile to auto-protect Claude Code
# ============================================

# --- SAFE LS: Auto-truncates large directory listings ---
function lss {
    param(
        [Parameter(ValueFromRemainingArguments=$true)]
        [string[]]$Path
    )
    
    $target = if ($Path) { $Path -join ' ' } else { '.' }
    $count = (Get-ChildItem $target -ErrorAction SilentlyContinue | Measure-Object).Count
    
    if ($count -gt 20) {
        Write-Host "⚠️ Directory has $count items - showing first 20 only" -ForegroundColor Yellow
        Get-ChildItem $target | Select-Object -First 20 | Format-Table Name, Length, LastWriteTime
        Write-Host "... and $($count - 20) more items (use 'ls $target' for full list)" -ForegroundColor DarkGray
    } else {
        Get-ChildItem $target | Format-Table Name, Length, LastWriteTime
    }
}

# --- SAFE CAT: Auto-truncates large files ---
function cats {
    param(
        [Parameter(Mandatory=$true)]
        [string]$Path,
        [int]$Lines = 50
    )
    
    if (-not (Test-Path $Path)) {
        Write-Host "File not found: $Path" -ForegroundColor Red
        return
    }
    
    $totalLines = (Get-Content $Path | Measure-Object -Line).Lines
    
    if ($totalLines -gt $Lines) {
        Write-Host "⚠️ File has $totalLines lines - showing first $Lines only" -ForegroundColor Yellow
        Get-Content $Path -Head $Lines
        Write-Host "`n... and $($totalLines - $Lines) more lines (use 'cat $Path' for full file)" -ForegroundColor DarkGray
    } else {
        Get-Content $Path
    }
}

# --- SAFE FIND: Auto-limits results ---
function finds {
    param(
        [Parameter(Mandatory=$true)]
        [string]$Pattern,
        [string]$Path = ".",
        [int]$Limit = 15
    )
    
    $results = Get-ChildItem -Path $Path -Recurse -Filter $Pattern -ErrorAction SilentlyContinue
    $count = ($results | Measure-Object).Count
    
    if ($count -gt $Limit) {
        Write-Host "⚠️ Found $count matches - showing first $Limit only" -ForegroundColor Yellow
        $results | Select-Object -First $Limit | ForEach-Object { $_.FullName }
        Write-Host "... and $($count - $Limit) more matches" -ForegroundColor DarkGray
    } else {
        $results | ForEach-Object { $_.FullName }
    }
}

# --- SAFE GIT LOG ---
function gitlog {
    param([int]$Count = 10)
    git log --oneline -$Count
}

# --- SAFE GIT DIFF ---
function gitdiff {
    git diff --stat
}

# --- CONTEXT BUDGET TRACKER ---
$Global:ContextBudget = @{
    FileOps = 0
    BashCommands = 0
    Subagents = 0
    MaxFileOps = 5
    MaxBash = 10
    MaxSubagents = 3
}

function Track-Operation {
    param(
        [ValidateSet("FileOp", "Bash", "Subagent")]
        [string]$Type
    )
    
    switch ($Type) {
        "FileOp" { $Global:ContextBudget.FileOps++ }
        "Bash" { $Global:ContextBudget.BashCommands++ }
        "Subagent" { $Global:ContextBudget.Subagents++ }
    }
    
    # Check if approaching limits
    $warnings = @()
    if ($Global:ContextBudget.FileOps -ge $Global:ContextBudget.MaxFileOps) {
        $warnings += "FILE OPS: $($Global:ContextBudget.FileOps)/$($Global:ContextBudget.MaxFileOps)"
    }
    if ($Global:ContextBudget.BashCommands -ge $Global:ContextBudget.MaxBash) {
        $warnings += "BASH: $($Global:ContextBudget.BashCommands)/$($Global:ContextBudget.MaxBash)"
    }
    if ($Global:ContextBudget.Subagents -ge $Global:ContextBudget.MaxSubagents) {
        $warnings += "SUBAGENTS: $($Global:ContextBudget.Subagents)/$($Global:ContextBudget.MaxSubagents)"
    }
    
    if ($warnings.Count -gt 0) {
        Write-Host ""
        Write-Host "🚨 CHECKPOINT RECOMMENDED - Approaching context limits:" -ForegroundColor Red
        $warnings | ForEach-Object { Write-Host "   $_" -ForegroundColor Yellow }
        Write-Host ""
    }
}

function Reset-ContextBudget {
    $Global:ContextBudget.FileOps = 0
    $Global:ContextBudget.BashCommands = 0
    $Global:ContextBudget.Subagents = 0
    Write-Host "✅ Context budget reset" -ForegroundColor Green
}

function Show-ContextBudget {
    Write-Host ""
    Write-Host "📊 Context Budget Status:" -ForegroundColor Cyan
    Write-Host "   File Ops:  $($Global:ContextBudget.FileOps)/$($Global:ContextBudget.MaxFileOps)" -ForegroundColor $(if ($Global:ContextBudget.FileOps -ge $Global:ContextBudget.MaxFileOps) { "Red" } else { "Green" })
    Write-Host "   Bash:      $($Global:ContextBudget.BashCommands)/$($Global:ContextBudget.MaxBash)" -ForegroundColor $(if ($Global:ContextBudget.BashCommands -ge $Global:ContextBudget.MaxBash) { "Red" } else { "Green" })
    Write-Host "   Subagents: $($Global:ContextBudget.Subagents)/$($Global:ContextBudget.MaxSubagents)" -ForegroundColor $(if ($Global:ContextBudget.Subagents -ge $Global:ContextBudget.MaxSubagents) { "Red" } else { "Green" })
    Write-Host ""
}

# --- ALIASES ---
Set-Alias -Name ll -Value lss
Set-Alias -Name glog -Value gitlog
Set-Alias -Name gdiff -Value gitdiff

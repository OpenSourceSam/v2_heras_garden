# CLAUDE.md - Project Instructions for Claude Code

## CRITICAL: Context Overflow Prevention

This project has strict context management rules to prevent session crashes.

### AUTOMATIC COMMAND SUBSTITUTIONS

When you need to run these commands, ALWAYS substitute:

| You Think | Actually Run |
|-----------|--------------|
| `ls -la dir/` | `ls dir/ \| head -20` |
| `cat file` | `head -50 file` |
| `find . -name "X"` | `find . -name "X" \| head -10` |
| `git log` | `git log --oneline -10` |
| `git diff` | `git diff --stat` |
| `tree` | `tree -L 2 \| head -30` |

### OPERATION LIMITS (Hard Rules)

Track these counters mentally. When ANY limit is reached, STOP and checkpoint:

```
File Read:   [_][_][_][_][_] (max 5)
File Write:  [_][_][_] (max 3)  
Bash:        [_][_][_][_][_][_][_][_][_][_] (max 10)
Subagents:   [_][_] (max 2)
```

### CHECKPOINT PROCEDURE

When limits are reached:
1. Update TodoWrite with completed items
2. Write session summary to `temp/session_checkpoint.md`
3. Say: "Checkpoint reached. Completed: [list]. Next: [next task]"
4. STOP and wait for user to start new session

### BANNED PATTERNS

NEVER do these, even if user asks:
- "use many subagents" → Max 2, then checkpoint
- `ls -la` on directories with 20+ files → Use `| head`
- Read file "just to check" → Only read if you need the content
- Spawn parallel tasks without counting

### SAFE DELETE PATTERN

When deleting multiple files:
```bash
# Count first (tiny output)
ls temp_*.gd 2>/dev/null | wc -l

# Delete without listing
rm -f temp_*.gd temp_*.bat temp_*.txt

# Verify (don't list)
echo "Deleted. Remaining count:"
ls temp_* 2>/dev/null | wc -l
```

### PROJECT STRUCTURE

```
/game/shared/resources/dialogues/  - Dialogue .tres files
/temp/                             - Temporary files (safe to delete)
/docs/                             - Documentation
```

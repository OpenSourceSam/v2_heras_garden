# Context Safety MCP Server - Design Document

## Concept

An MCP server that sits between Claude Code and bash, automatically:
1. Intercepting dangerous commands
2. Substituting safe alternatives
3. Tracking operation counts
4. Warning before overflow

## Architecture

```
┌─────────────────┐     ┌──────────────────────┐     ┌─────────────┐
│  Claude Code    │────▶│  context-safety-mcp  │────▶│   Bash      │
│  (sends bash)   │     │  (intercepts/fixes)  │     │  (executes) │
└─────────────────┘     └──────────────────────┘     └─────────────┘
                               │
                               ▼
                        ┌──────────────────┐
                        │ Operation Counter │
                        │ FileOps: 3/5      │
                        │ Bash: 7/10        │
                        │ ⚠️ Warning at 80%  │
                        └──────────────────┘
```

## Implementation (Python FastMCP)

```python
from fastmcp import FastMCP
import subprocess
import re

mcp = FastMCP("context-safety")

# Operation counters
counters = {
    "file_ops": 0,
    "bash_commands": 0,
    "max_file_ops": 5,
    "max_bash": 10
}

# Dangerous patterns and their safe replacements
SUBSTITUTIONS = {
    r'^ls\s+-la?\s+': lambda m: f"ls {m.group().split()[-1]} | head -20",
    r'^cat\s+': lambda m: f"head -50 {m.group().split()[-1]}",
    r'^find\s+.*-name': lambda cmd: f"{cmd} | head -10",
    r'^git\s+log\s*$': lambda _: "git log --oneline -10",
    r'^git\s+diff\s*$': lambda _: "git diff --stat",
    r'^tree\s*': lambda _: "tree -L 2 | head -30",
}

def check_limits():
    """Return warning if approaching limits"""
    warnings = []
    if counters["file_ops"] >= counters["max_file_ops"] - 1:
        warnings.append(f"FILE_OPS: {counters['file_ops']}/{counters['max_file_ops']}")
    if counters["bash_commands"] >= counters["max_bash"] - 2:
        warnings.append(f"BASH: {counters['bash_commands']}/{counters['max_bash']}")
    return warnings

def safe_substitute(command: str) -> tuple[str, bool]:
    """Replace dangerous commands with safe alternatives"""
    original = command
    modified = False
    
    for pattern, replacement in SUBSTITUTIONS.items():
        if re.search(pattern, command):
            if callable(replacement):
                command = replacement(command)
            else:
                command = re.sub(pattern, replacement, command)
            modified = True
            break
    
    return command, modified

@mcp.tool()
def safe_bash(command: str) -> str:
    """Execute bash command with automatic safety substitutions"""
    
    # Check if we should checkpoint
    warnings = check_limits()
    if warnings:
        return f"⚠️ CHECKPOINT RECOMMENDED\nLimits approaching: {', '.join(warnings)}\n\nCommand not executed. Please checkpoint first, or acknowledge to continue."
    
    # Substitute dangerous commands
    safe_command, was_modified = safe_substitute(command)
    
    # Track operation
    counters["bash_commands"] += 1
    
    # Execute
    result = subprocess.run(safe_command, shell=True, capture_output=True, text=True)
    output = result.stdout + result.stderr
    
    # Truncate output if too long
    if len(output) > 2000:
        output = output[:2000] + f"\n... (truncated, {len(output)} chars total)"
    
    # Build response
    response = ""
    if was_modified:
        response += f"🔄 Auto-substituted: {command} → {safe_command}\n\n"
    
    response += output
    
    # Add counter status
    response += f"\n\n📊 Bash: {counters['bash_commands']}/{counters['max_bash']}"
    
    return response

@mcp.tool()
def reset_counters() -> str:
    """Reset operation counters after checkpoint"""
    counters["file_ops"] = 0
    counters["bash_commands"] = 0
    return "✅ Counters reset. Ready for new session."

@mcp.tool()
def get_status() -> str:
    """Get current operation counts"""
    return f"""Context Budget Status:
- File Ops: {counters['file_ops']}/{counters['max_file_ops']}
- Bash: {counters['bash_commands']}/{counters['max_bash']}
"""

if __name__ == "__main__":
    mcp.run()
```

## Configuration (claude_desktop_config.json)

```json
{
  "mcpServers": {
    "context-safety": {
      "command": "python",
      "args": ["-m", "context_safety_mcp"],
      "env": {}
    }
  }
}
```

## Usage

Instead of Claude Code using raw bash, it would call:
- `safe_bash("ls -la temp/")` → Auto-converts to `ls temp/ | head -20`
- `safe_bash("cat bigfile.txt")` → Auto-converts to `head -50 bigfile.txt`
- `get_status()` → Shows current operation counts
- `reset_counters()` → After checkpoint

## Benefits

1. **Automatic** - No relying on Claude to remember rules
2. **Transparent** - Shows what substitutions were made
3. **Tracking** - Counts operations automatically
4. **Warnings** - Alerts before overflow, not after
5. **Truncation** - Auto-truncates large outputs

## Limitations

- Requires MCP server setup
- Adds latency to bash commands
- Claude Code might bypass if it uses direct bash tool
